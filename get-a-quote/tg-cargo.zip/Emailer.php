<?php

$path = dirname(dirname(__FILE__));

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once('./PHPMailer/src/Exception.php');
require_once('./PHPMailer/src/PHPMailer.php');
require_once('./PHPMailer/src/SMTP.php');


class Emailer
{
    var $mail;

    public function __construct($subject = null)
    {
        $mail = new PHPMailer(true);
        try {
            //Enable SMTP debugging.
            $mail->SMTPDebug = 0;
            //Set PHPMailer to use SMTP.
            $mail->isSMTP();
            //Set SMTP host name                          
            $mail->Host = "mail.globalwebdreams.in";
            //Set this to true if SMTP host requires authentication to send email
            $mail->SMTPAuth = true;
            //Provide username and password                   
            $mail->Username = "_mainaccount@globalwebdreams.in";
            $mail->Password = "t8Fy4ER#$3w8tT12";
            //Set TCP port to connect to
            $mail->Port = 587;

            $mail->From = 'roykumar19@gmail.com';
            $mail->FromName = 'Kumar Roy';
            $mail->addAddress('roykumar19@gmail.com');
            $mail->addAddress('shriraj@circadian-ca.com');
            $mail->addAddress('omkar@circadian-ca.com');

            $mail->Subject = $subject;

            $mail->isHTML(true);
        } catch (Exception $e) {
            echo "Mailer Configuration Error: {$mail->ErrorInfo}";
        }

        $this->mail = $mail;
    }

    function sendMail($message, $refid)
    {
        $this->mail->MsgHTML($message);
        try {
            $this->mail->send();
            echo $refid;
        } catch (Exception $e) {
            echo "Mailer Error: " . $this->mail->ErrorInfo;
        }
    }
}
