<?php

require_once('./Emailer.php');

if ($_POST) {
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];
    $cargo_ready_date = $_POST['cargo_ready_date'];
    $ct_20GP = $_POST['ct_20GP'];
    $ct_40GP = $_POST['ct_40GP'];
    $ct_40HC = $_POST['ct_40HC'];
    $ct_45HC = $_POST['ct_45HC'];
    $cargo_detail = $_POST['cargo_detail'];
    $commodity = $_POST['commodity'];
    $temp_range = isset($_POST['temp_range']) ? $_POST['temp_range'] : "";
    $un_no = isset($_POST['un_no']) ? $_POST['un_no'] : "";
    $imco_range = isset($_POST['imco_range']) ? $_POST['imco_range'] : "";
    $note = $_POST['note'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = isset($_POST['mobile']) ? $_POST['mobile'] : "-";

    $emailer = new Emailer('FCL Test mail');

    $refid = time() . rand(10 * 45, 100 * 98);

    $email_content = "<html><body><h4>Reference Number: $refid</h4>";
    $email_content .= "<table style='font-family: Arial;'><tbody>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Name</td><td style='background: #fda; padding: 10px;'>$name</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Email</td><td style='background: #fda; padding: 10px;'>$email</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Mobile</td><td style='background: #fda; padding: 10px;'>$mobile</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Origin</td><td style='background: #fda; padding: 10px;'>$origin</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Destination</td><td style='background: #fda; padding: 10px;'>$destination</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Cargo Ready Date</td><td style='background: #fda; padding: 10px;'>$cargo_ready_date</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>20GP</td><td style='background: #fda; padding: 10px;'>$ct_20GP</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>40GP</td><td style='background: #fda; padding: 10px;'>$ct_40GP</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>40HC</td><td style='background: #fda; padding: 10px;'>$ct_40HC</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>45HC</td><td style='background: #fda; padding: 10px;'>$ct_45HC</td></tr>";
    $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Commodity</td><td style='background: #fda; padding: 10px;'>$commodity</td></tr>";
    if ($cargo_detail == "Hazardous") {
        $email_content .= "<tr><td style='background: #eee; padding: 10px;'>UN No.</td><td style='background: #fda; padding: 10px;'>$un_no</td></tr>";
        $email_content .= "<tr><td style='background: #eee; padding: 10px;'>IMCO Range</td><td style='background: #fda; padding: 10px;'>$imco_range</td></tr>";
    }
    if ($cargo_detail == "Reefer") {
        $email_content .= "<tr><td style='background: #eee; padding: 10px;'>Temp Range</td><td style='background: #fda; padding: 10px;'>$temp_range</td></tr>";
    }
    $email_content .= "</tbody></table>";
    $email_content .= "<p style='font-family: Arial;'><strong>Note : (Shipping Reference)</strong><i> $note</i>.</p>";
    $email_content .= '</body></html>';

    // echo $email_content;
    $emailer->sendMail($email_content, $refid);
}
